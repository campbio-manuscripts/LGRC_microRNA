semisupervised.clustering <- function (x, row.class, hclustfun=hclust, distfun=dist) {
	# Function to reorder the rows of a matrix using hierarchical clustering within two specified classes
	# Adam Gower, 2009
	#
	# INPUT
	# x        	a matrix on which semisupervised clustering will be performed
	# row.class	an integer vector, of length ncol(x), that denotes the class of each row
	# hclustfun	the function used to perform hierarchical clustering
	# distfun	the function used to provide a distance matrix for hierarchical clustering
	#
	# OUTPUT
	# A dendrogram of the reordered rows; the root node will have attributes 'height' and 'midpoint' set to NA

	# Get the set of unique classes and sort it
	classes <- sort(unique(row.class));
	# Use hierarchical clustering to cluster rows, once within each class, and create a dendrogram from the result
	dd <- list();
	attributes(dd) <- list(members=0, midpoint=NA, height=NA, class="dendrogram");
	for (i in 1:length(classes)) {
		class.indices <- which(row.class == classes[i]);
		if (length(class.indices) > 1) {
			# If there is more than one row of the current class, create a sub-dendrogram
			dd[[i]] <- as.dendrogram(hclustfun(distfun(x[class.indices,])));
			# Change indices of sub-dendrogram from 1..number of rows in class to corresponding row indices in x
			dd[[i]] <- dendrapply(dd[[i]], function(x) { if(is.leaf(x)) x[1] <- class.indices[x[1]]; x; });
			# Update the leaf count of the entire dendrogram
			attributes(dd)$members <- attributes(dd)$members + attributes(dd[[i]])$members;
		} else {
			# If there is only one row of the given class, add it as a leaf of the dendrogram
			dd[[i]] <- class.indices;
			attributes(dd[[i]]) <- list(label=rownames(x)[class.indices], members=1, height=0, leaf=TRUE);
			attributes(dd)$members <- attributes(dd)$members + 1;
		}
	}
	# If there is only one class, move the sub-dendrogram up to the root node
	if (length(classes) == 1) dd <- dd[[1]];
	return(dd);
}
