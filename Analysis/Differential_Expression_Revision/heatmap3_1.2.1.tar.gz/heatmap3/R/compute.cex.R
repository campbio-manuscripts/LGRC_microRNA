compute.cex <- function (label, width, height, units="inches") {
	# Adam Gower, 2009
	# Computes the cex factor needed to place a label (or the largest in a vector of labels) in a given plot region

	# label		string of text to be drawn, or a character vector of text strings to be drawn, the largest of which will be used for computations
	# width		width of the plot region in which to draw the text
	# height	height of the plot region in which to draw the text
	# units		units in which width and height are reported

	# Determine the aspect ratio (W:H) of the plot region
	region.aspect <- width / height;

	# Get the width, height, and aspect ratio of the (largest) label
	label.width <- max(strwidth(label, units=units));
	label.height <- max(strheight(label, units=units));
	label.aspect <- label.width / label.height;

	# Compute the cex factor that will place the text completely within the plot region 
	cex.label <- ifelse(label.aspect > region.aspect, width/label.width, height/label.height);

	return(cex.label);
}
