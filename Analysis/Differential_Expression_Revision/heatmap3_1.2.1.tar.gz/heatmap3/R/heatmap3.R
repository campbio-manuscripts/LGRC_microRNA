heatmap3 <- function (x, Rowv = NULL, Colv = if (symm) "Rowv" else NULL,
                      distfun = dist, hclustfun = hclust, reorderfun = function(d, w) reorder(d, w),
		      add.expr, symm = FALSE, revC = TRUE, scale = c("row", "column", "none"), na.rm = TRUE,
		      margins = NULL, RowSideColors = NULL, ColSideColors = NULL, cexRow = NULL, cexCol = NULL,
		      labRow = NULL, labCol = NULL, main = NULL, xlab = NULL, ylab = NULL,
		      keep.dendro = FALSE, verbose = getOption("verbose"),
		      row.clustering = "unsupervised", col.clustering = "unsupervised",
		      row.dendrogram = TRUE, col.dendrogram = TRUE,
		      z.trim = c(-2, 2), cex.lim = 1, col = heat.colors(256), ...)
{

	# This is a replacement for the heatmap() function.  It has a number of substantial improvements over the original, including:
	#      - user-friendly parameters for specifying clustering and dendrogram plotting (including the suppression of dendrograms!)
	#      - performing 'semisupervised' clustering, i.e., clustering separately within the sidebar classes (and plot dendrograms as well)
	#      - automatically resizing margins to fit row and column labels, and vice versa
	#      - automatically resizing the title margin to fit the title
	#      - the ability to draw multiple heatmaps on a single device
	#      - applying z-score cutoffs to the scaled heatmap matrix (to prevent outliers from skewing the color distribution)
	#
	# This function is almost completely backwards-compatible.  However, some behaviors have been changed, on the grounds that these make more sense:
	#      - the use of split.screen() instead of layout(), which allows multiple heatmaps to be drawn on a single device
	#      - the revC parameter now defaults to TRUE instead of FALSE, so that row 1 of the matrix is plotted at the top of the heatmap, not the bottom
	#      - if 'scale' = "row" or "column", the z-score normalization is applied BEFORE hierarchical clustering, not after
	#      - 'margins', 'cexRow', and 'cexCol' do not have defaults, as they are computed from the row and column labels instead
	#      - the order of 'RowSideColors' and 'ColSideColors' is swapped in the argument list (so that Row arguments always come before Col arguments)
	#      - 'RowSideColors' and 'ColSideColors' can be character vectors, OR matrices with one or more sidebars, as in heatmap.plus()
	#      - 'col' has been added as an explicit argument, rather than as a possible ... argument to image() (does not change behavior of function)
	#
	# Written by Adam Gower, 2008-2010
	# Based on the heatmap() function originally written by Andy Liaw and revised by R. Gentleman, M. Maechler and W. Huber  
	# 
	# INPUT
	# x               numeric matrix that will be plotted as heatmap
	# Rowv            dendrogram for reordering the rows of the heatmap, or NA to suppress reordering of rows
	# Colv            dendrogram for reordering the cols of the heatmap, or NA to suppress reordering of cols; setting to "Rowv" treats rows and columns the same  
	# distfun         specifies the distance function to be used for hierarchical clustering
	# hclustfun       specifies the hierarchical clustering function to be used
	# reorderfun      specifies the function to be used for reordering dendrograms
	# add.expr        expression to evaluate before plotting dendrograms
	# symm            here for backwards compatibility, only to set Colv to "Rowv"; otherwise moot
	# revC            here for backwards compatibility; in contrast to heatmap(), this defaults to TRUE (top row of heatmap = row 1, which is more intuitive)
	# scale           one of either "row", "column", or "none"; specifies the direction in which z-normalization will be applied to x
	# na.rm           should NA values be removed?
	# margins         two-element vector that specifies the margins for column and row names, respectively
	# RowSideColors   either a vector of length nrow(x) or a matrix with nrow(x) rows, of type "character"; specifies colors for sidebar labeling
	# ColSideColors   either a vector of length ncol(x) or a matrix with ncol(x) columns, of type "character"; specifies colors for sidebar labeling
	# cexRow          character expansion (cex) factor for row labels
	# cexCol          character expansion (cex) factor for column labels
	# labRow          character vector specifying row labels
	# labCol          character vector specifying column labels
	# main            character string specifying heatmap title
	# xlab            character string specifying x axis label
	# ylab            character string specifying y axis label
	# keep.dendro     logical value; specifies whether or not to return the information describing the dendrograms
	# verbose         logical value; specifies whether to print messages during plotting
	# row.clustering  one of either "supervised", "unsupervised", or "semisupervised", to specify method for clustering rows of heatmap,
	#                 or an integer-coercible vector to be used for semisupervised clustering
	# col.clustering  one of either "supervised", "unsupervised", or "semisupervised", to specify method for clustering rows of heatmap,
	#                 or an integer-coercible vector to be used for semisupervised clustering
	# row.dendrogram  logical value; specifies whether or not to draw the dendrogram of row clustering (suppressed if row.clustering is not "unsupervised")
	# col.dendrogram  logical value; specifies whether or not to draw the dendrogram of row clustering (suppressed if row.clustering is not "unsupervised")
	# z.trim          two-element vector that specifies the lower and upper z-score cutoffs to apply to the z-normalized matrix
	# cex.lim         limit placed on cex factors to prevent enormous labels
	# col             character string specifying the color palette to use
	# ...             further arguments passed to image()
	
	# When this function is exited, make sure all split.screen() screens are closed
	# Fixed this on 08-13-09: was closing ALL split.screen instances, making it impossible to draw more than one heatmap per page
	heatmap.screens <- NULL;
	on.exit(if (length(heatmap.screens)) close.screen(n=heatmap.screens));

	scale <- if (missing(scale)) ifelse(symm, "none", "row") else match.arg(scale);
	if (is.character(row.clustering)) {
		row.clustering <- match.arg(row.clustering, c("unsupervised", "semisupervised", "supervised"));
	} else {
		row.clustering <- as.integer(row.clustering);
	}
	if (is.character(col.clustering)) {
		col.clustering <- match.arg(col.clustering, c("unsupervised", "semisupervised", "supervised"));
	} else {
		col.clustering <- as.integer(col.clustering);
	}

	# Get dimensions of matrix x
	nr <- nrow(x);
	nc <- ncol(x);
#	if (nr < 2 || nc < 2) stop("'x' must have at least 2 rows and 2 columns");

	ddr <- ddc <- NULL;

	# In the symmetric case, copy the row clustering settings to the column clustering settings
	if (identical(Colv, "Rowv")) {
		if (nr == nc) {
			ColSideColors <- RowSideColors;
			col.clustering <- row.clustering;
			col.dendrogram <- row.dendrogram;
		} else {
			stop('Colv = "Rowv" but nrow(x) != ncol(x)');
		}
	}

	# Check to make sure that RowSideColors and ColSideColors arguments are the correct size, and coerce to matrices
	if (!is.null(RowSideColors)) {
		if (NROW(RowSideColors) == nr) {
			RowSideColors <- as.matrix(RowSideColors);
		} else {
			stop("'RowSideColors' must be a vector of length nrow(x) or a matrix with nrow(x) rows.");
		}
	}
	if (!is.null(ColSideColors)) {
		if (NROW(ColSideColors) == nc) {
			ColSideColors <- as.matrix(ColSideColors);
		} else {
			stop("'ColSideColors' must be a vector of length ncol(x) or a matrix with ncol(x) rows.");
		}
	}

	# As with previous version of heatmap(), setting Rowv or Colv to NA suppresses hierarchical clustering
	if (identical(Rowv, NA)) row.clustering <- "supervised";
	if (identical(Colv, NA)) col.clustering <- "supervised";
	
	# Just in case, suppress drawing of dendrograms if none will be generated
	if (identical(row.clustering, "supervised")) row.dendrogram <- FALSE;
	if (identical(col.clustering, "supervised")) col.dendrogram <- FALSE;

	############################################## CREATE HEATMAP LAYOUT ##############################################

	# Create zeroed-out layout matrix with enough rows and columns to hold sidebars and dendrograms
	lrows <- 1+(!is.null(ColSideColors))+col.dendrogram+!is.null(main);
	lcols <- 1+(!is.null(RowSideColors))+row.dendrogram; 
	lmat <- matrix(0, nrow=lrows, ncol=lcols);
	# Plot heatmap of length 4 and width 4 first
	lmat[lrows, lcols] <- panel <- 1;
	lwid <- lhei <- c(4);
	# Add row side color bar of width 0.2 if specified
	if (!is.null(RowSideColors)) {
		lmat[lrows, lcols-1] <- panel <- panel + 1;
		lwid <- c(0.2, lwid);
	}
	# Add column side color bar of height 0.2 if specified
	if (!is.null(ColSideColors)) {
		lmat[lrows-1, lcols] <- panel <- panel + 1;
		lhei <- c(0.2, lhei);
	}
	# Add row dendrogram window of width 1 if specified
	if (row.dendrogram) {
		lmat[lrows, lcols-1-(!is.null(RowSideColors))] <- panel <- panel + 1;
		lwid <- c(1, lwid);
	}
	# Add column dendrogram window of height 1 if specified
	if (col.dendrogram) {
		lmat[lrows-1-(!is.null(ColSideColors)), lcols] <- panel <- panel + 1;
		lhei <- c(1, lhei);
	}
	# Add title window of height 0.5 if specified
	if (!is.null(main)) {
		# Compute the number of lines in the title
		main.nlines <- length(unlist(strsplit(main, "\n")));
		lmat[1, lcols] <- panel <- panel + 1;
		lhei <- c(0.25 * main.nlines, lhei);
	}

	if (verbose) {
		cat("layout: widths = ", lwid, ", heights = ", lhei, "\nlmat=\n");
		print(lmat);
	}

	heatmap.figs <- matrix(nrow=max(lmat), ncol=4);
	lwid <- lwid / sum(lwid);
	lhei <- lhei / sum(lhei);
	cumsum.lwid <- cumsum(c(0,lwid));
	cumsum.lhei <- 1 - cumsum(c(0,lhei));
	for (i in 1:lrows) {
		for (j in 1:lcols) {
			if (lmat[i,j])
				heatmap.figs[lmat[i,j],] <- c(left=cumsum.lwid[j], right=cumsum.lwid[j+1], bottom=cumsum.lhei[i+1], top=cumsum.lhei[i]);
		}
	}
	heatmap.screens <- split.screen(figs=heatmap.figs);

	# Z-normalize heatmap if requested, trimming at specified z-value cutoffs
	znorm <- function (x, na.rm = TRUE) {
		mu <- mean(x, na.rm = na.rm);
		x.minus.mu <- x - mu;
		ssq.x <- sum(x.minus.mu^2, na.rm = na.rm);
		n <- if (na.rm) sum(!is.na(x)) else length(x);
		sd.x <- sqrt(ssq.x / (n-1));
		return(x.minus.mu / sd.x);
	}
	if (scale %in% c("row", "column")) {
		z.direction <- switch(scale, row=1, column=2);
		x <- apply(x, z.direction, znorm);
		if (scale == "row") x <- t(x);
		x[x < z.trim[1]] <- z.trim[1];
		x[x > z.trim[2]] <- z.trim[2];
	}

	if (identical(row.clustering, "unsupervised")) {
		# Perform unsupervised clustering
		if (inherits(Rowv, "dendrogram")) {
			ddr <- Rowv;
		} else {
			Rowv <- rowMeans(x, na.rm = na.rm);
			ddr <- as.dendrogram(hclustfun(distfun(x)));
			ddr <- reorderfun(ddr, Rowv);
		}
	} else if (identical(row.clustering, "semisupervised")) {
		# Perform semisupervised clustering using the color vectors as the groups
		ddr <- semisupervised.clustering(x, RowSideColors[,1], hclustfun, distfun);
	} else if (is.integer(row.clustering)) {
		# Perform semisupervised clustering using the row.clustering argument as the groups
		ddr <- semisupervised.clustering(x, row.clustering, hclustfun, distfun);
	}

	if (identical(col.clustering, "unsupervised")) {
		# Perform unsupervised clustering
		if (inherits(Colv, "dendrogram")) {
			ddc <- Colv;
		} else {
			Colv <- colMeans(x, na.rm = na.rm);
			ddc <- as.dendrogram(hclustfun(distfun(t(x))));
			ddc <- reorderfun(ddc, Colv);
		}
	} else if (identical(col.clustering, "semisupervised")) {
		# Perform semisupervised clustering using the color vectors as the groups
		ddc <- semisupervised.clustering(t(x), ColSideColors[,1], hclustfun, distfun);
	} else if (is.integer(col.clustering)) {
		# Perform semisupervised clustering using the row.clustering argument as the groups
		ddc <- semisupervised.clustering(t(x), col.clustering, hclustfun, distfun);
	}

	# Get order of row and column indices based on clustering types specified
	rowInd <- if (identical(row.clustering, "supervised")) 1:nr else order.dendrogram(ddr);
	colInd <- if (identical(col.clustering, "supervised")) 1:nc else order.dendrogram(ddc);

	# New default is to reverse row indices (and dendrogram, if one was requested), because image() plots row 1 at the bottom of the heatmap by default
	# This is equivalent to setting the archaic parameter 'revC' to TRUE, which reordered the columns of the _transposed_ heatmap matrix (i.e., the rows!)
	# This is the opposite of the default in heatmap(), which is to set 'revC' to FALSE (unless 'symm' was set to TRUE)
	if (revC) {
		rowInd <- rev(rowInd);
		if (row.dendrogram) ddr <- rev(ddr);
	}
	
	# Reorder the heatmap matrix according to the row and column indices
	x <- x[rowInd, colInd];
	
	# If row labels were not specified, create them from the row names of matrix x; otherwise, reorder the labels specified in labRow
	if (is.null(labRow)) {
		labRow <- if (is.null(rownames(x))) (1:nr)[rowInd] else rownames(x);
	} else if (!all(is.na(labRow))) {
		labRow <- labRow[rowInd];
	}

	# If column labels were not specified, create them from the column names of matrix x; otherwise, reorder the labels specified in labCol
	if (is.null(labCol)) {
		labCol <- if (is.null(colnames(x))) (1:nc)[colInd] else colnames(x);
	} else if (!all(is.na(labCol))) {
		labCol <- labCol[colInd];
	}

	############################################## PLOT HEATMAP ELEMENTS ##############################################

	# Establish margin between heatmap elements and edges of page and convert to inches
	page.margin <- 0.5 * par("csi");
	# Establish margin between axes of heatmap field and row/column labels and convert to inches
	axis.margin <- 0.5 * par("csi");

	frame();

	if (is.null(margins)) {
		# Compute bottom & right margins (in inches) from row and column labels if none were supplied
		margins <- compute.margins(labRow, labCol, cexRow, cexCol, cex.lim, page.margin = page.margin / par("csi"), axis.margin = axis.margin / par("csi"), units="inches");
	} else {
		# Check for correct 'margins' argument; if OK, convert to inches
		if (!is.numeric(margins) || length(margins) != 2) {
			stop("'margins' must be a numeric vector of length 2");
		}
		margins <- margins * par("csi");
	}
	names(margins) <- c("bottom", "right");

	# Margins to add space in case there are no other elements between the heatmap and the edge of the drawing area
	left.page.margin <- if (is.null(RowSideColors) && (!row.dendrogram)) page.margin else 0;
	top.page.margin <- if (is.null(ColSideColors) && (!col.dendrogram) && is.null(main)) page.margin else 0;
	
	# Set par("mgp")[2] (axis-specific margin line) to axis.margin
	mgp <- par("mgp");
	par(mgp=c(mgp[1], axis.margin / par("csi"), mgp[3]));
	# Set margins for heatmap, leaving bottom margin for column labels and right margin for row labels
	par(mai=c(margins["bottom"]+page.margin+axis.margin, left.page.margin, top.page.margin, margins["right"]+page.margin+axis.margin));

	# Plot main heatmap
	image(1:nc, 1:nr, t(x), xlim = 0.5 + c(0, nc), ylim = 0.5 + c(0, nr), axes = FALSE, xlab = "", ylab = "", col=col, ...);

	# Evaluate 'add.expr' if it was supplied
	if (!missing(add.expr)) eval(substitute(add.expr));
	
	# Plot the column labels and any x axis label that was supplied
	if (!all(is.na(labCol))) {
		if (is.null(cexCol)) {
			cexCol <- compute.cex(labCol, margins["bottom"], (par("fin")[1] - margins["right"] - page.margin - axis.margin) / nc);
		}
		axis(1, 1:nc, labels = labCol, las = 2, tick = 0, cex.axis = cexCol);
	}
	if (!is.null(xlab)) mtext(xlab, side = 1, line = (margins["bottom"] + page.margin) / par("csi") - 1.25);
	# Plot the row labels and any y axis label that was supplied 
	if (!all(is.na(labRow))) {
		if (is.null(cexRow)) {
			cexRow <- compute.cex(labRow, margins["right"], (par("fin")[2] - margins["bottom"] - page.margin - axis.margin) / nr);
		}
		axis(4, 1:nr, labels = labRow, las = 2, tick = 0, cex.axis = cexRow);
	}
	if (!is.null(ylab)) mtext(ylab, side = 4, line = (margins["right"] + page.margin) / par("csi") - 1.25);
	current.screen <- screen();
	heatmap.screens <- setdiff(heatmap.screens, current.screen);
	close.screen(current.screen);

	# Plot row side colors if they were supplied
	if (!is.null(RowSideColors)) {
		# Coerce row side colors to matrix
		RowSideColors <- as.matrix(RowSideColors);
		# Get any track names that were specified
		row.tracks <- colnames(RowSideColors);
		# Convert row side colors to factor (in case color names were specified)
		RowSideColors <- as.factor(RowSideColors[rowInd,]);
		# Set margins, leaving bottom margin for column labels and 10% left and right margins
#		par(mai = c(margins["bottom"]+page.margin+axis.margin, 0.1*par("fin")[1], top.page.margin, 0.1*par("fin")[1]));
		par(mai = c(margins["bottom"]+page.margin+axis.margin, ifelse(row.dendrogram, 0.1*par("fin")[1], page.margin), top.page.margin, 0.1*par("fin")[1]));
		# Plot row side colors; if color names were specified in the RowSideColors argument, they will be passed as 'col' argument
		image(1:(length(RowSideColors)/nr), 1:nr, t(matrix(as.numeric(RowSideColors), nrow=nr)), col=levels(RowSideColors), axes = FALSE, xlab=NA, ylab=NA);
		# If track names were specified, write them
		if (!is.null(row.tracks)) {
			par(cex.axis = 0.95 * compute.cex(label = row.tracks, width = margins["bottom"] / par("csi") * par("cin")[1], height = 0.8 * par("fin")[1] / length(row.tracks)));
			axis(side=1, at=1:length(row.tracks), labels=row.tracks, line=-0.5, tick=FALSE, las=2);
		}
		current.screen <- screen();
		heatmap.screens <- setdiff(heatmap.screens, current.screen);
		close.screen(current.screen);
	}

	# Plot column side colors if they were supplied
	if (!is.null(ColSideColors)) {
		# Coerce column side colors to matrix
		ColSideColors <- as.matrix(ColSideColors);
		# Get any track names that were specified
		col.tracks <- colnames(ColSideColors);
		# Convert column side colors to factor (in case color names were specified)
		ColSideColors <- as.factor(ColSideColors[colInd,]);
		# Set margins, leaving right margin for row labels and 10% bottom and top margins
#		par(mai = c(0.1*par("fin")[2], left.page.margin, 0.1*par("fin")[2], margins["right"]+page.margin+axis.margin));
		par(mai = c(0.1*par("fin")[2], left.page.margin, ifelse(!is.null(main), 0.1*par("fin")[2], page.margin), margins["right"]+page.margin+axis.margin));
		# Plot column side colors; if color names were specified in the RowSideColors argument, they will be passed as 'col' argument
		image(1:nc, 1:(length(ColSideColors)/nc), matrix(as.numeric(ColSideColors), nrow=nc), col=levels(ColSideColors), axes = FALSE, xlab=NA, ylab=NA);
		# If track names were specified, write them
		if (!is.null(col.tracks)) {
			par(cex.axis = 0.95 * compute.cex(label = col.tracks, width = margins["right"] / par("csi") * par("cin")[1], height = 0.8 * par("fin")[2] / length(col.tracks)));
#			if (verbose) cat(sprintf("cex.axis for col.tracks is %g\n", par("cex.axis"))); 
			axis(side=4, at=1:length(col.tracks), labels=col.tracks, line=-0.5, tick=FALSE, las=2);
		}
		current.screen <- screen();
		heatmap.screens <- setdiff(heatmap.screens, current.screen);
		close.screen(current.screen);
	}

	# Plot row dendrogram if requested
	if (row.dendrogram) {
		# Set margins for row dendrogram panel, leaving bottom margin for column labels
		par(mai = c(margins["bottom"] + page.margin + axis.margin, page.margin, top.page.margin, 0));
		plot(ddr, horiz = TRUE, axes = FALSE, yaxs = "i", leaflab = "none", xlim=c(max(attributes(ddr)$height, sapply(ddr, function(x) attributes(x)$height), na.rm=TRUE), 0));
		current.screen <- screen();
		heatmap.screens <- setdiff(heatmap.screens, current.screen);
		close.screen(current.screen);
	}

	# Plot column dendrogram if requested
	if (col.dendrogram) {
		# Set margins for column dendrogram panel, leaving right margin for row labels
		par(mai = c(0, left.page.margin, ifelse(!is.null(main), 0, page.margin), margins["right"] + page.margin + axis.margin));
		plot(ddc, horiz = FALSE, axes = FALSE, xaxs = "i", leaflab = "none", ylim=c(0, max(attributes(ddc)$height, sapply(ddc, function(x) attributes(x)$height), na.rm=TRUE)));
		current.screen <- screen();
		heatmap.screens <- setdiff(heatmap.screens, current.screen);
		close.screen(current.screen);
	}
	
	# Add main title if requested
	if (!is.null(main)) {
		par(mai=c(0, left.page.margin, page.margin, margins["right"] + page.margin + axis.margin), xpd=NA);
		frame();
		cex.main <- min(cex.lim, compute.cex(label=main, width=par("fin")[1]-left.page.margin-margins["right"]-page.margin-axis.margin, height=par("fin")[2]-page.margin));
#		if (verbose) cat(sprintf("cex.main = %0.3g\n", cex.main));
		text(x=0.5, y=0.5, labels=main, font=1, cex=cex.main);
		current.screen <- screen();
		heatmap.screens <- setdiff(heatmap.screens, current.screen);
		close.screen(current.screen);
	}

#	if (verbose) cat(sprintf("labCol.width = %g, labRow.width = %g\n", labCol.width, labRow.width));
#	if (verbose) cat(sprintf("labCol.height = %g, labRow.height = %g\n", labCol.height, labRow.height));
#	if (verbose) cat(sprintf("ar.labRow = %g, ar.labCol = %g\n", ar.labRow, ar.labCol));
#	if (verbose) cat(sprintf("par('fin') = c(%g, %g), nr=%d, nc=%d\n", par("fin")[1], par("fin")[2], nr, nc));
#	if (verbose) cat(sprintf("max.bottom.margin = %g, max.right.margin = %g\n", bottom.margin, right.margin));
#	if (verbose) cat(sprintf("bottom.margin = %g, right.margin = %g\n", bottom.margin, right.margin));
#	if (verbose) cat(sprintf("cexRow = %g, cexCol = %g\n", cexRow, cexCol));
	
	# Return list of row and column indices, and dendrograms, if requested
	invisible(list(rowInd = rowInd, colInd = colInd, Rowv = if (keep.dendro && !identical(Rowv, NA)) ddr, Colv = if (keep.dendro && !identical(Colv, NA)) ddc));
}

