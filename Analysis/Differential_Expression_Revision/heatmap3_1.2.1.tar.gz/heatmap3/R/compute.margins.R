compute.margins <- function (labRow, labCol, cexRow = NULL, cexCol = NULL, cex.lim = 1,
                             screen.width = par("fin")[1], screen.height = par("fin")[2],
                             page.margin = 0.5, axis.margin = 0.5, units = c("inches", "user")) {
	# Helper function to compute bottom and right-side margins for heatmap3()
	# Adam Gower
	#
	# INPUT
	# labRow          character vector specifying row labels
	# labCol          character vector specifying column labels
	# cexRow          character expansion (cex) factor for row labels
	# cexCol          character expansion (cex) factor for column labels
	# cex.lim         limit placed on cex factors to prevent enormous labels
	# screen.width    the screen width in inches
	# screen.height   the screen height in inches
	# page.margin     the margin applied to the edge of the page (device), in user units
	# axis.margin     the margin applied to the edge of the axis, in user units
	# units           character string, either "inches" or "user", denoting how the margins should be returned
	#
	# OUTPUT
	# A two-element numeric vector, containing the bottom and right-side margins, respectively.
	
	units <- match.arg(units);
	
	nr <- length(labRow);
	nc <- length(labCol);
	
	# Note: for some reason, strwidth(x, "user") / par("csi") != strwidth(x, "inches"); same for strheight().
	# Because of this, all calculations are done internally in inches for consistency.
	labRow.width <- max(strwidth(labRow, units="inches"));
	labRow.height <- max(strheight(labRow, units="inches"));
	labCol.width <- max(strwidth(labCol, units="inches"));
	labCol.height <- max(strheight(labCol, units="inches"));

	# If the cex factor is supplied for the row or column labels, scale the labels accordingly to determine the margins
	if (!is.null(cexRow)) {
		labRow.width <- cexRow * labRow.width;
		labRow.height <- cexRow * labRow.height;
	}
	if (!is.null(cexCol)) {
		labCol.width <- cexCol * labCol.width;
		labCol.height <- cexCol * labCol.height;
	}
	# Aspect ratios for the row and column labels
	ar.labRow <- labRow.width / labRow.height;
	ar.labCol <- labCol.width / labCol.height;

	# Maximum margin widths are based on the cex limit
	max.right.margin <- cex.lim * labRow.width;
	max.bottom.margin <- cex.lim * labCol.width;

	# Automatically set margins so that aspect ratio of the label space is equal to the aspect ratio of the longest label
	figure.width <- screen.width - (page.margin + axis.margin) * par("csi");
	figure.height <- screen.height - (page.margin + axis.margin) * par("csi");

	bottom.margin <- right.margin <- page.margin * par("csi");
	if (labCol.height == 0) {
		if (labRow.height > 0) {
			right.margin <- min(ar.labRow * (figure.height - bottom.margin) / nr, max.right.margin);
		}
	} else {
		if (labRow.height == 0) {
			bottom.margin <- min(ar.labCol * (figure.width - right.margin) / nc, max.bottom.margin);
		} else {
			bottom.margin <- min(ar.labCol * (ar.labRow * figure.height - figure.width * nr) / (ar.labRow * ar.labCol - nr * nc), max.bottom.margin);
			if (bottom.margin < 0) {
				right.margin <- ar.labRow * (ar.labCol * figure.width - figure.height * nc) / (ar.labCol * ar.labRow - nc * nr);
				bottom.margin <- ar.labCol * (figure.width - right.margin) / nc;
			} else {
				right.margin <- min(ar.labRow * (figure.height - bottom.margin) / nr, max.right.margin);
			}
		}
	}

	margins <- c(bottom.margin, right.margin);

	if (units == "user") {
		margins <- margins / par("csi");
	}

	return(margins);
}

